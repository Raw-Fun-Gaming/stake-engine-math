"""Output formatting modules for game simulation results."""
