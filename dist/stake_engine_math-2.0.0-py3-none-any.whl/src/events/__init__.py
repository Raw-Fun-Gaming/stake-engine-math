"""Event system for game simulations."""

from src.events.event_filter import EventFilter

__all__ = ["EventFilter"]
